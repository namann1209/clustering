rm(list=ls(all=TRUE));
Sys.time()
library(foreign)
library(maptools)
library(raster)
library(rgeos)
require(rgdal)
require(sp)
library(locfit)
library(lattice)
library(kriging)
library(xlsx)
library(geosphere)
library(kmeans)
library(plyr)
library(data.table)
library(TSP)
#-----------------------------------------------
epsg = 24313

zip_poly=readShapeSpatial('D:/segment_out_q3/tl_2017_us_zcta510.shp.ea.iso/tl_2017_us_zcta510.shp')





zip_cent=zip_poly@data



coords= centroid(zip_poly)
zip_cent=SpatialPointsDataFrame(coords, zip_cent)
min(distGeo(zip_cent[1,],zip_cent[2:33144,]))


for(i in 1:length(zip_cent@data$MTFCC10)){
  a=distGeo(zip_cent[i,],zip_cent)
  con1=data.frame('zip'=zip_cent@data$ZCTA5CE10[i],'neigh'=zip_cent@data$ZCTA5CE10[a<3000])
  con2=data.frame('zip'=zip_cent@data$ZCTA5CE10[i],'neigh'=zip_cent@data$ZCTA5CE10[a<5000])
  con3=data.frame('zip'=zip_cent@data$ZCTA5CE10[i],'neigh'=zip_cent@data$ZCTA5CE10[a<7000])
  if(i==1){l1=con1; l2= con2; l3=con3}
  if(i!=1){l1=rbind(l1,con1); l2= rbind(l2,con2); l3=rbind(l3,con3)}
  if(i==1500){l1=l1[l1$zip!=l1$neigh,];l2=l2[l2$zip!=l2$neigh,];l3=l3[l3$zip!=l3$neigh,]}
}

l1=l1[l1$zip!=l1$neigh,]
l2=l2[l2$zip!=l2$neigh,]
l3=l3[l3$zip!=l3$neigh,]

length(unique(l1$zip))
length(unique(l2$zip))
length(unique(l3$zip))

write.csv(l1,'E:/OneDrive/US zip/zip_poly/neigh_3.csv')
write.csv(l2,'E:/OneDrive/US zip/zip_poly/neigh_5.csv')
write.csv(l3,'E:/OneDrive/US zip/zip_poly/neigh_7.csv')

rm(l1,l2,l3)


coords=data.frame(coords)
for(i in 32275:length(zip_poly@data$MTFCC10)){
  z1=zip_poly[abs(coords$X1-coords$X1[i])<0.5 & abs(coords$X2-coords$X2[i])<0.5,]
  a=gIntersects(zip_poly[i,],z1,byid = TRUE)
  con1=data.frame('zip'=zip_poly@data$ZCTA5CE10[i],'neigh'=z1@data$ZCTA5CE10[a])
  if(i==1){l1=con1}
  if(i!=1){l1=rbind(l1,con1)}
  if(i==1500){l1=l1[l1$zip!=l1$neigh,]}
}
l1=l1[l1$zip!=l1$neigh,]
length(unique(l1$zip))

write.csv(l1,'E:/OneDrive/US zip/zip_poly/neigh_int.csv')

