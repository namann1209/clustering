setwd('D:/poppy.chanda/data')
library(dplyr)
library(magrittr)
data_seg <- read.csv('zip_seg_vol.csv')
data_age <- read.csv('zip_age_pop.csv')

data_age_sub <- select(data_age, 
                       zip_code,
                       total_pop,
                       X20_to_24 : X85.)


merged <- merge(data_seg,data_age_sub,by = 'zip_code')

#########################################################

### subset data for different segments
# seglist <- c('CORE','CORE.Plus...Premium','FMB','H.E','N.A'','VALUE')

seg  <- 'CORE'

subsetted <- select(merged,
                    zip_code,
                    seg,
                    total_pop:X85.)

## converting factor variables to numeric  
subsetted[,4:17] = apply(subsetted[,4:17], 2, function(x) as.numeric(as.character(x)));


# creating _ variables

subsetted$Pop_20 = subsetted$total_pop * subsetted$X20_to_24
subsetted$Pop_25 = subsetted$total_pop * subsetted$X25_to_29
subsetted$Pop_30 = subsetted$total_pop * subsetted$X30_to_34
subsetted$Pop_35 = subsetted$total_pop * subsetted$X35_to_39
subsetted$Pop_40 = subsetted$total_pop * subsetted$X40_to_44
subsetted$Pop_45 = subsetted$total_pop * subsetted$X45_to_49
subsetted$Pop_50 = subsetted$total_pop * subsetted$X50_to_54
subsetted$Pop_55 = subsetted$total_pop * subsetted$X55_to_59
subsetted$Pop_60 = subsetted$total_pop * subsetted$X60_to_64
subsetted$Pop_65 = subsetted$total_pop * subsetted$X65_to_69
subsetted$Pop_70 = subsetted$total_pop * subsetted$X70_to_74
subsetted$Pop_75 = subsetted$total_pop * subsetted$X75_to_79
subsetted$Pop_80 = subsetted$total_pop * subsetted$X80_to_84
subsetted$Pop_85 = subsetted$total_pop * subsetted$X85


# subsetting data for regression
regData <- select(subsetted, seg,  Pop_20:Pop_85)

#log of original data 
test<-log(regData)

# Regression model
regModel <- lm(log(1+VALUE) ~ log(1+Pop_20)+ log(1+Pop_25) +
                 log(1+Pop_30) + log(1+Pop_35) +
                 log(1+Pop_40) + log(1+Pop_45) +
                 log(1+Pop_50) + log(1+Pop_55) +
                 log(1+Pop_60) + log(1+Pop_65) +
                 log(1+Pop_70) + log(1+Pop_75) +
                 log(1+Pop_80) + log(1+Pop_85), data = test, na.action = na.omit)


summary(regModel)
coefficients(regModel)
confint(regModel)
fitted(regModel)
residuals(regModel)
