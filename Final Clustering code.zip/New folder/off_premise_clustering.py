# -*- coding: utf-8 -*-

import pandas as pd
import datetime as dt
import sys
import numpy as np
import os

sys.path.extend(['D:\suraj.jha\test_clust_info'])
sys.path.extend(['C:\BlockParty\SrvApps\ZipAnalytics_TEST\Feature_Engineering'])

from connect_to_azure import *

root_path = r'D:\suraj.jha\test_clust_info'
db_schema = 'zip_analytics_test'
timestamp = dt.datetime.now().strftime("d%Y%m%d_t%H%M%S")

rtlr_query = "select * from [%s].[acct_dtl_extract]" % db_schema
rtlr_df = sql_execute(rtlr_query)
rtlr_df.columns = map(str.lower, map(str, rtlr_df.columns))
rtlr_df = rtlr_df.drop_duplicates('rtlr_party_id')
rtlr_df.to_csv(os.path.join(root_path, r'1_raw_data\SQL_tables_data\account_detail.csv'), index=False, encoding='utf-8')
rtlr_df = rtlr_df[['rtlr_party_id', 'zip', 'state_cd']]
rtlr_df['rtlr_party_id'] = rtlr_df['rtlr_party_id'].astype(int)

zip_metro_file = os.path.join(root_path, r'1_raw_data\zip_metro_mapping.xlsx')
zip_metro = pd.read_excel(zip_metro_file)
zip_metro = zip_metro[['zip', 'cbsa', 'tot_ratio']]
zip_metro['max_tot_ratio'] = zip_metro.groupby(['zip'])['tot_ratio'].transform(max)
zip_metro = zip_metro[zip_metro['tot_ratio']==zip_metro['max_tot_ratio']].drop_duplicates(['zip']).drop(['tot_ratio', 'max_tot_ratio'],axis=1)
 
cbsa_metro_file = os.path.join(root_path, r'1_raw_data\cbsa_metro_micro.xlsx')
cbsa_metro = pd.read_excel(cbsa_metro_file)
cbsa_metro = cbsa_metro[['CBSA Code', 'Metropolitan/Micropolitan Statistical Area']]
cbsa_metro = cbsa_metro.drop_duplicates()

rsu_file = os.path.join(root_path, r'2_derived_data\result_rural_urban.csv')
rsu_df = pd.read_csv(rsu_file)
rsu_df = rsu_df[['rtlr_party_id','geo_cluster']]

alteryx_query = 'select rtlr_num, cyec17v001, xcyea06v001, xcya08v002, cypopdens from [%s].[rtlr_num_external_data]' % db_schema
altyx_df = sql_execute(alteryx_query)
altyx_df.columns = ['rtlr_party_id', 'medinc', 'perc_hisp', 'perc_aa', 'density']

final_df = pd.merge(rtlr_df,
                    rsu_df,
                    how='left',
                    on='rtlr_party_id')
                    
final_df = pd.merge(final_df,
                    altyx_df,
                    how='left',
                    on='rtlr_party_id')
                    
final_df['zip'] = pd.to_numeric(final_df['zip'].fillna(0).replace('-----', 0)) 
final_df = pd.merge(final_df,
                    zip_metro,
                    how='left',
                    on='zip')
                    
final_df['cbsa'] = final_df['cbsa'].fillna(0).astype(int)
cbsa_metro['CBSA Code'] = cbsa_metro['CBSA Code'].fillna(0).astype(int)
final_df = pd.merge(final_df,
                    cbsa_metro,
                    how='left',
                    left_on='cbsa',
                    right_on='CBSA Code').drop('CBSA Code',axis=1)

##load census data
census = pd.read_csv(os.path.join(root_path, r'1_raw_data\ACS_16_5YR_S0101_with_ann.csv'))

#subset for columns which are needed (Median in this nugget)
census_filtered = pd.concat([pd.DataFrame(census.iloc[:,[1,3]]),census.loc[:,'HC01_EST_VC35']],axis=1)
census_filtered = census_filtered.iloc[1:,]

census_filtered.columns =['zip','tot_pop','med_age']

census_filtered.replace('*****',0,inplace=True)
census_filtered.replace('-',0,inplace=True)
census_filtered.replace('**',0,inplace=True)
census_filtered['zip'] = pd.to_numeric(census_filtered['zip'])
census_filtered['med_age'] = pd.to_numeric(census_filtered['med_age'])
census_filtered['tot_pop'] = pd.to_numeric(census_filtered['tot_pop'])
census_filtered = census_filtered.loc[census_filtered['med_age']!=0]

final_df = pd.merge(final_df,
                    census_filtered[['zip','med_age']],
                    how='left',
                    on='zip')

final_df.loc[final_df.zip==0,'zip'] = np.NaN
final_df.to_csv(os.path.join(root_path, r'2_derived_data\merged_file_%s.csv') %timestamp, index=False)

#################  Mising value imputations #######################

# ### layer 1 imputation

layer1=final_df
layer1['zip1']=layer1.groupby('zip')['geo_cluster'].transform(lambda x:x.mode())
layer1['geo2']=layer1.geo_cluster.combine_first(layer1.zip1)
layer1.drop(['geo_cluster','zip1'],axis=1,inplace=True)
layer1.rename(columns={'geo2':'geo_cluster'},inplace=True)

layer1["medinc"]=pd.to_numeric(layer1["medinc"])
layer1["medinc"].fillna(layer1.groupby("zip")["medinc"].transform("mean"), inplace=True)
layer1["perc_hisp"].fillna(layer1.groupby("zip")["perc_hisp"].transform("mean"), inplace=True)
layer1["perc_aa"].fillna(layer1.groupby("zip")["perc_aa"].transform("mean"), inplace=True)
layer1["density"].fillna(layer1.groupby("zip")["density"].transform("mean"), inplace=True)
layer1["med_age"].fillna(layer1.groupby("zip")["med_age"].transform("mean"), inplace=True)


### layer 2 imputation

layer2 = layer1
zip_neighbours = os.path.join(root_path, r'1_raw_data\neigh_int.csv')
df_neigh = pd.read_csv(zip_neighbours)[['zip','neigh']]

## Neigh imputation start geo_cluster
neigh=pd.DataFrame(df_neigh['neigh'].unique())
neigh.columns=['neigh']

final_df=layer2
test=final_df
t1=test[['zip','geo_cluster']]
new=pd.merge(neigh,t1,how='inner',left_on='neigh',right_on='zip')

new=new[['neigh','geo_cluster']].drop_duplicates()
new['mode']=new.groupby('neigh')['geo_cluster'].transform(lambda x:x.mode())
new1=pd.DataFrame(new.groupby('neigh')['geo_cluster'].max().reset_index())
data= pd.merge(df_neigh,new1,how='left',left_on='neigh',right_on='neigh')## Code to merge back with neigh comes here
data['mode']= data.groupby('zip')['geo_cluster'].transform(lambda x:x.mode())### Code to find zip leve mode comes here
## Code to take max to avoid multiple modes comes here
data=data[['zip','mode']].drop_duplicates()
newdata = pd.DataFrame(data.groupby('zip')['mode'].max().reset_index())
test1=pd.merge(test,newdata,how='left',left_on='zip',right_on='zip')
test1['geo_cluster']=test1.geo_cluster.combine_first(test1['mode'])### final step
layer2=test1.drop('mode',axis=1)


## Neigh imputation start Medinc
neigh=pd.DataFrame(df_neigh['neigh'].unique())
neigh.columns=['neigh']
final_df=layer2
test=final_df
t1=test[['zip','medinc']]
new=pd.merge(neigh,t1,how='inner',left_on='neigh',right_on='zip')

new['mean']=new.groupby('neigh')['medinc'].transform("mean")
new=new[['neigh','mean']]
data= pd.merge(df_neigh,new,how='left',left_on='neigh',right_on='neigh')## Code to merge back with neigh comes here
data=data[['zip','mean']]
data['mean'].fillna(0,inplace=True)
data['mean']= data.groupby('zip')['mean'].transform('mean')### Code to find zip leve mode comes here
data=data.drop_duplicates()
test1=pd.merge(test,data,how='left',left_on='zip',right_on='zip')
test1['medinc']=test1.medinc.combine_first(test1['mean'])### final ste
layer2=test1.drop('mean',axis=1)


## Neigh imputation start PercHisp
neigh=pd.DataFrame(df_neigh['neigh'].unique())
neigh.columns=['neigh']
final_df=layer2
test=final_df
t1=test[['zip','perc_hisp']]
new=pd.merge(neigh,t1,how='inner',left_on='neigh',right_on='zip')

new['mean']=new.groupby('neigh')['perc_hisp'].transform("mean")
new=new[['neigh','mean']]
data= pd.merge(df_neigh,new,how='left',left_on='neigh',right_on='neigh')## Code to merge back with neigh comes here
data=data[['zip','mean']]
data['mean'].fillna(0,inplace=True)
data['mean']= data.groupby('zip')['mean'].transform('mean')### Code to find zip leve mode comes here
data=data.drop_duplicates()
test1=pd.merge(test,data,how='left',left_on='zip',right_on='zip')
test1['perc_hisp']=test1.perc_hisp.combine_first(test1['mean'])### final step
layer2=test1.drop('mean',axis=1)


## Neigh imputation start Percaa
neigh=pd.DataFrame(df_neigh['neigh'].unique())
neigh.columns=['neigh']
final_df=layer2
test=final_df
t1=test[['zip','perc_aa']]
new=pd.merge(neigh,t1,how='inner',left_on='neigh',right_on='zip')

new['mean']=new.groupby('neigh')['perc_aa'].transform("mean")
new=new[['neigh','mean']]
data= pd.merge(df_neigh,new,how='left',left_on='neigh',right_on='neigh')## Code to merge back with neigh comes here
data=data[['zip','mean']]
data['mean'].fillna(0,inplace=True)
data['mean']= data.groupby('zip')['mean'].transform('mean')### Code to find zip leve mode comes here
data=data.drop_duplicates()
test1=pd.merge(test,data,how='left',left_on='zip',right_on='zip')
test1['perc_aa']=test1.perc_aa.combine_first(test1['mean'])### final step
layer2=test1.drop('mean',axis=1)

## Neigh imputation start Density
neigh=pd.DataFrame(df_neigh['neigh'].unique())
neigh.columns=['neigh']
final_df=layer2
test=final_df
t1=test[['zip','density']]
new=pd.merge(neigh,t1,how='inner',left_on='neigh',right_on='zip')

new['mean']=new.groupby('neigh')['density'].transform("mean")
new=new[['neigh','mean']]
data= pd.merge(df_neigh,new,how='left',left_on='neigh',right_on='neigh')## Code to merge back with neigh comes here
data=data[['zip','mean']]
data['mean'].fillna(0,inplace=True)
data['mean']= data.groupby('zip')['mean'].transform('mean')### Code to find zip leve mode comes here
data=data.drop_duplicates()
test1=pd.merge(test,data,how='left',left_on='zip',right_on='zip')
test1['density']=test1.density.combine_first(test1['mean'])
layer2=test1.drop('mean',axis=1)

## Neigh imputation start median age
neigh=pd.DataFrame(df_neigh['neigh'].unique())
neigh.columns=['neigh']
final_df=layer2
test=final_df
t1=test[['zip','med_age']]
new=pd.merge(neigh,t1,how='inner',left_on='neigh',right_on='zip')

new['mean']=new.groupby('neigh')['med_age'].transform("mean")
new=new[['neigh','mean']]
data= pd.merge(df_neigh,new,how='left',left_on='neigh',right_on='neigh')## Code to merge back with neigh comes here
data=data[['zip','mean']]
data['mean'].fillna(0,inplace=True)
data['mean']= data.groupby('zip')['mean'].transform('mean')### Code to find zip leve mode comes here
data=data.drop_duplicates()
test1=pd.merge(test,data,how='left',left_on='zip',right_on='zip')
test1['med_age']=test1.med_age.combine_first(test1['mean'])
layer2=test1.drop('mean',axis=1)


### Layer 3

layer3=layer2

dma_zip = 'SELECT distinct [zip] ,[dma_key] FROM [%s].[zip_dma]' % db_schema
dma_zip_df = sql_execute(dma_zip)
dma_zip_df['zip']=dma_zip_df.zip.astype('float64')

layer3 = pd.merge(layer3, dma_zip_df, how='left', on = 'zip')

layer3['zip1']=layer3.groupby('dma_key')['geo_cluster'].transform(lambda x:x.mode())
layer3['geo2']=layer3.geo_cluster.combine_first(layer3.zip1)
layer3.drop(['geo_cluster','zip1'],axis=1,inplace=True)

layer3.rename(columns={'geo2':'geo_cluster'},inplace=True)

layer3["medinc"].fillna(layer3.groupby("dma_key")["medinc"].transform("mean"), inplace=True)
layer3["perc_hisp"].fillna(layer3.groupby("dma_key")["perc_hisp"].transform("mean"), inplace=True)
layer3["perc_aa"].fillna(layer3.groupby("dma_key")["perc_aa"].transform("mean"), inplace=True)
layer3["density"].fillna(layer3.groupby("dma_key")["density"].transform("mean"), inplace=True)
layer3["med_age"].fillna(layer3.groupby("dma_key")["med_age"].transform("mean"), inplace=True)


## Layer 4


layer4=layer3

layer4['zip1']=layer4.groupby('state_cd')['geo_cluster'].transform(lambda x:x.mode())
layer4['geo2']=layer4.geo_cluster.combine_first(layer4.zip1)
layer4.drop(['geo_cluster','zip1'],axis=1,inplace=True)
layer4.rename(columns={'geo2':'geo_cluster'},inplace=True)

layer4["medinc"].fillna(layer4.groupby("state_cd")["medinc"].transform("mean"), inplace=True)
layer4["perc_hisp"].fillna(layer4.groupby("state_cd")["perc_hisp"].transform("mean"), inplace=True)
layer4["perc_aa"].fillna(layer4.groupby("state_cd")["perc_aa"].transform("mean"), inplace=True)
layer4["density"].fillna(layer4.groupby("state_cd")["density"].transform("mean"), inplace=True)
layer4["med_age"].fillna(layer4.groupby("state_cd")["med_age"].transform("mean"), inplace=True)


non_null_zips = layer4.loc[layer4.zip.isnull()==False,:]


imputed_df = non_null_zips
imputed_df = imputed_df.drop('dma_key',axis=1)


###################################################### imputation of all layers stop here

result = imputed_df

result['med_income_thresh'] = result.groupby(['state_cd', 'geo_cluster'])['medinc'].transform('median')
result['geo_cluster_income'] = result.apply(lambda x: str(x['geo_cluster'])+ ' High Income' if x['medinc'] >= x['med_income_thresh'] else str(x['geo_cluster'])+ ' Low Income',axis=1)

threshold = {"perc_hisp" : [26, 59],
             "perc_aa" : 40,
             "med_age": [34, 42]}

perc_hisp_max = max(threshold["perc_hisp"])
perc_hisp_min = min(threshold["perc_hisp"])

med_age_min = min(threshold["med_age"])
med_age_max = max(threshold["med_age"])


#naming the age_clusters
def age_cluster(arg):
    if arg['med_age'] < med_age_min:
        return 'Young-Age'
    elif arg['med_age'] > med_age_max:
        return 'Older-Age'
    else:
        return 'Middle-Age'


def rtlr_num_clust(x):

    if x['perc_hisp']  >  perc_hisp_max and x['geo_cluster'] == 'Urban':
        return 'Hispanic Urban '
    
    elif x['perc_hisp']  >  perc_hisp_max:
        return 'Hispanic Non-Urban'
    
    elif x['perc_hisp']  >  perc_hisp_min and x['geo_cluster'] == 'Urban': 
        return 'Med Hispanic Urban'
          
    elif x['perc_hisp']  >  perc_hisp_min:
        return 'Med Hispanic Non-Urban'

    elif x['perc_aa']    >  threshold["perc_aa"] and x['geo_cluster'] == 'Urban': 
     return 'African American Urban'
         
    elif x['perc_aa']    >  threshold["perc_aa"]:
        return 'African American Non-Urban'
    
    else:
        return 'General Mkt ' + str(x['geo_cluster_income'])

result['rtlr_num_clust'] = result.apply(rtlr_num_clust, axis=1)
result['age_cluster'] = result.apply(age_cluster,axis=1)
 
#writing the desired outputs
result.to_csv(os.path.join(root_path, r'4_output_data\rtlr_num_cluster_result_detail.csv'), index=False)
result[['rtlr_party_id', 'rtlr_num_clust', 'age_cluster', 'zip']].to_csv(os.path.join(root_path, r'4_output_data\off_permise_rtlr_num_clusters.csv'), index=False, header=None)

