rm(list=ls(all=TRUE));
library(rgdal);
library(dismo);
library(geosphere);
library(PBSmapping);
######################################################################################################################################################################################################################################
#rural & urban:
data<-readOGR(dsn="D:\\suraj.jha\\test_clust_info\\1_raw_data\\US shapefiles\\urban area shapefile",layer="tl_2017_us_uac10",stringsAsFactors=FALSE);
data1<-read.csv('D:\\suraj.jha\\test_clust_info\\1_raw_data\\SQL_tables_data\\account_detail.csv',stringsAsFactors=FALSE,row.names="rtlr_party_id");
data1$rtlr_party_id<-row.names.data.frame(data1);
data1<-data1[c("rtlr_party_id","crctd_lattd_nbr","crctd_lngtd_nbr")];
data1$crctd_lattd_nbr<-as.numeric(data1$crctd_lattd_nbr);
data1$crctd_lngtd_nbr<-as.numeric(data1$crctd_lngtd_nbr);
data1<-subset(data1, is.na(crctd_lattd_nbr)==F & is.na(crctd_lngtd_nbr)==F);
data1<-subset(data1, crctd_lattd_nbr>18   & crctd_lattd_nbr<155);
coordinates(data1)<-c("crctd_lngtd_nbr","crctd_lattd_nbr");
proj4string(data1)<-CRS("+proj=longlat +datum=NAD83 +no_defs +ellps=GRS80 +towgs84=0,0,0");
data2<-over(data1,data);
data2$RURAL_DUMMY<-ifelse(is.na(data2$GEOID)==TRUE,1,0);
data2$rtlr_party_id<-row.names.data.frame(data2);
data2<-data2[c("rtlr_party_id","RURAL_DUMMY")];   
write.csv(data2,'D:\\suraj.jha\\test_clust_info\\2_derived_data\\RURAL_URBAN_STATUS.csv',row.names=FALSE);
######################################################################################################################################################################################################################################
#urban and suburban
data<-readOGR(dsn="D:\\suraj.jha\\test_clust_info\\1_raw_data\\US shapefiles\\places shapefile",layer="all_places_2017_shapfile",stringsAsFactors=FALSE);
data3<-over(data1,data);
data3$rtlr_party_id<-row.names.data.frame(data3);
data3<-data3[c("rtlr_party_id","PLACEFP","STATEFP")];
data3<-subset(data3, is.na(PLACEFP)==F);
write.csv(data3,'D:\\suraj.jha\\test_clust_info\\2_derived_data\\PLACE_RETAILER_MAPPING.csv',row.names=FALSE)
######################################################################################################################################################################################################################################