# -*- coding: utf-8 -*-
"""
Created on Fri Feb 23 09:05:23 2018

@author: ALTZ100066
"""

import pandas as pd
import datetime as dt


timestamp = dt.datetime.now().strftime("d%Y%m%d_t%H%M%S")

u_s_r = pd.read_csv(r'D:\suraj.jha\test_clust_info\2_derived_data\RURAL_URBAN_STATUS.csv')

prncpl_ct = pd.read_excel(r'D:\suraj.jha\test_clust_info\1_raw_data\principal_cities.xls')
prncpl_ct = prncpl_ct[['FIPS State Code', 'FIPS Place Code']]

rtlr_place = pd.read_csv(r'D:\suraj.jha\test_clust_info\2_derived_data\PLACE_RETAILER_MAPPING.csv')

sub_urb = pd.merge(rtlr_place,
                   prncpl_ct,
                   how='left',
                   left_on=['STATEFP','PLACEFP'],
                   right_on=['FIPS State Code', 'FIPS Place Code'])
                   
sub_urb['urban_dummy'] = ~sub_urb['FIPS Place Code'].isnull()
sub_urb['urban_dummy'] = sub_urb['urban_dummy'].apply(lambda x: 1 if x else 0)

sub_urb = sub_urb[['rtlr_party_id', 'urban_dummy']]

result = pd.merge(u_s_r,
                  sub_urb,
                  how='left',
                  on='rtlr_party_id').fillna(0)
                  
result['suburb_dummy'] = 0
result.loc[result['RURAL_DUMMY'] == result['urban_dummy'],'suburb_dummy'] = 1
result.loc[result['RURAL_DUMMY'] == result['urban_dummy'],['urban_dummy', 'RURAL_DUMMY']]  = [0, 0]                

result.loc[result['RURAL_DUMMY'] == 1,'geo_cluster'] = 'Rural'
result.loc[result['urban_dummy'] == 1,'geo_cluster'] = 'Urban'
result.loc[result['suburb_dummy'] == 1,'geo_cluster'] = 'Suburb'

result.to_csv(r'D:\suraj.jha\test_clust_info\2_derived_data\result_rural_urban.csv',index=False)
